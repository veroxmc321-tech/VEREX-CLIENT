package com.verex.launcher

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.view.WindowManager.LayoutParams
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** A basic floating launcher panel. Its switches are UI-only until a supported game integration exists. */
class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var floatingView: LinearLayout? = null
    private var panelView: LinearLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!android.provider.Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createFloatingButton()
    }

    private fun createFloatingButton() {
        val button = TextView(this).apply {
            text = "V"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(70, 180, 255))
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(12, 28, 48))
            setOnClickListener { togglePanel() }
        }
        floatingView = LinearLayout(this).apply {
            addView(button, LinearLayout.LayoutParams(dp(56), dp(56)))
        }
        val params = LayoutParams(
            dp(56), dp(56),
            LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12)
            y = dp(180)
        }
        try {
            windowManager.addView(floatingView, params)
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun togglePanel() {
        if (panelView != null) {
            try { windowManager.removeView(panelView) } catch (_: Exception) {}
            panelView = null
            return
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.rgb(8, 15, 27))
        }
        panel.addView(TextView(this).apply {
            text = "VEREX CLIENT"
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(65, 173, 255))
            setPadding(0, 0, 0, dp(8))
        })
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Render", "Combat", "HUD", "Profile", "Settings").forEach { tab ->
            tabRow.addView(Button(this).apply {
                text = tab
                textSize = 9f
                setOnClickListener {
                    Toast.makeText(this@OverlayService, "$tab: panel awal; integrasi game belum tersedia.", Toast.LENGTH_SHORT).show()
                }
            }, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        panel.addView(tabRow)
        panel.addView(TextView(this).apply {
            text = "Kontrol visual game belum dihubungkan. Tombol ini tidak mengubah mekanik Minecraft."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(8), 0, dp(8))
        })
        panel.addView(Button(this).apply {
            text = "Tutup menu"
            setOnClickListener { togglePanel() }
        })
        panelView = panel
        val params = LayoutParams(
            dp(320), LayoutParams.WRAP_CONTENT,
            LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12)
            y = dp(245)
        }
        try {
            windowManager.addView(panel, params)
        } catch (_: Exception) {
            panelView = null
            Toast.makeText(this, "Tidak dapat menampilkan panel overlay.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        try { panelView?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        try { floatingView?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        panelView = null
        floatingView = null
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
