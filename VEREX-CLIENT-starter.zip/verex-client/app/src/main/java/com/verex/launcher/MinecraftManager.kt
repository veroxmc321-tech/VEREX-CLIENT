package com.verex.launcher

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/** Uses Android's package visibility and launch APIs; it does not inspect Minecraft private data. */
data class MinecraftInfo(
    val packageName: String,
    val versionName: String,
    val versionCode: Long
)

object MinecraftManager {
    const val PACKAGE_NAME = "com.mojang.minecraftpe"

    fun getInstalledMinecraft(context: Context): MinecraftInfo? {
        val pm = context.packageManager
        return try {
            val packageInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(
                    PACKAGE_NAME,
                    PackageManager.PackageInfoFlags.of(0)
                )
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(PACKAGE_NAME, 0)
            }

            val code = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                packageInfo.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                packageInfo.versionCode.toLong()
            }
            MinecraftInfo(
                packageName = PACKAGE_NAME,
                versionName = packageInfo.versionName ?: "Unknown",
                versionCode = code
            )
        } catch (_: PackageManager.NameNotFoundException) {
            null
        } catch (_: SecurityException) {
            null
        }
    }

    fun openMinecraft(context: Context): Boolean {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(PACKAGE_NAME)
            ?: return false
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(launchIntent)
            true
        } catch (_: ActivityNotFoundException) {
            false
        } catch (_: SecurityException) {
            false
        }
    }
}
