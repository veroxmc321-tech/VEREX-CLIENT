package com.verex.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 12, 20)
    private val panel = Color.rgb(13, 23, 38)
    private val blue = Color.rgb(53, 167, 255)
    private val pale = Color.rgb(235, 245, 255)
    private val muted = Color.rgb(145, 169, 195)
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildDashboard()
    }

    private fun buildDashboard() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            setBackgroundColor(bg)
        }
        scroll.addView(root)

        val logo = TextView(this).apply {
            text = "V"
            textSize = 42f
            setTypeface(null, Typeface.BOLD)
            setTextColor(blue)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(16, 39, 70))
        }
        root.addView(logo, LinearLayout.LayoutParams(dp(72), dp(72)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(12)
        })
        root.addView(label("VEREX CLIENT", 26f, pale, true).apply {
            gravity = Gravity.CENTER
        })
        root.addView(label("BEDROCK EDITION · ANDROID", 12f, blue, true).apply {
            gravity = Gravity.CENTER
        }, marginParams(top = 4, bottom = 26))

        root.addView(label("PLAYER PROFILE", 17f, pale, true), marginParams(bottom = 8))
        root.addView(label("Microsoft login belum dikonfigurasi. Tombol login resmi akan dihubungkan setelah pendaftaran aplikasi Microsoft.", 13f, muted), cardParams(bottom = 12))
        root.addView(actionButton("LOGIN MICROSOFT (BELUM AKTIF)") {
            Toast.makeText(this, "Login Microsoft memerlukan konfigurasi aplikasi Microsoft terlebih dahulu.", Toast.LENGTH_LONG).show()
        }, matchParams(bottom = 24))

        root.addView(label("YOUR MINECRAFT", 17f, pale, true), marginParams(bottom = 8))
        status = label("Tekan Periksa Minecraft untuk mendeteksi game yang terpasang.", 14f, muted)
        root.addView(status, cardParams(bottom = 12))
        root.addView(actionButton("PERIKSA MINECRAFT") { checkMinecraft() }, matchParams(bottom = 10))
        root.addView(actionButton("PLAY MINECRAFT") { launchMinecraft() }, matchParams(bottom = 24))

        root.addView(label("IN-GAME OVERLAY", 17f, pale, true), marginParams(bottom = 8))
        root.addView(label("Ikon V mengambang memerlukan izin Android khusus. Fitur di dalam overlay pada versi awal adalah panel UI; kontrol game yang tidak didukung tidak akan dipalsukan.", 13f, muted), cardParams(bottom = 12))
        root.addView(actionButton("AKTIFKAN IKON VEREX") { enableOverlay() }, matchParams(bottom = 10))
        root.addView(actionButton("BUKA HALAMAN MINECRAFT PLAY STORE") {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=${MinecraftManager.PACKAGE_NAME}"))
            startActivity(intent)
        }, matchParams(bottom = 24))

        root.addView(label("v0.1.0 · BLACK + NEON BLUE", 11f, muted).apply { gravity = Gravity.CENTER })
        setContentView(scroll)
    }

    private fun checkMinecraft() {
        val info = MinecraftManager.getInstalledMinecraft(this)
        status.text = if (info == null) {
            "Minecraft Bedrock tidak terdeteksi. Pastikan game resmi terpasang dari Play Store."
        } else {
            "Minecraft Bedrock terdeteksi\nVersi: ${info.versionName}\nVersion code: ${info.versionCode}"
        }
    }

    private fun launchMinecraft() {
        val info = MinecraftManager.getInstalledMinecraft(this)
        if (info == null) {
            status.text = "Minecraft belum terdeteksi. Periksa instalasi terlebih dahulu."
            Toast.makeText(this, "Minecraft Bedrock tidak ditemukan.", Toast.LENGTH_LONG).show()
            return
        }
        if (!MinecraftManager.openMinecraft(this)) {
            Toast.makeText(this, "Android tidak dapat membuka Minecraft.", Toast.LENGTH_LONG).show()
        }
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            Toast.makeText(this, "Aktifkan Izinkan ditampilkan di atas aplikasi lain, lalu kembali ke VEREX.", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "Ikon VEREX diaktifkan.", Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        // Refresh status when the user returns from Android overlay-permission settings.
        if (::status.isInitialized && Settings.canDrawOverlays(this)) {
            // Do not automatically start the overlay; the user must press the button.
        }
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(dp(2), dp(2), dp(2), dp(2))
    }

    private fun actionButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(18, 75, 125))
        textSize = 13f
        setOnClickListener { action() }
    }

    private fun cardParams(bottom: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply {
        setMargins(0, 0, 0, dp(bottom))
    }

    private fun matchParams(bottom: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, dp(52)
    ).apply { setMargins(0, 0, 0, dp(bottom)) }

    private fun marginParams(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(0, dp(top), 0, dp(bottom)) }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
