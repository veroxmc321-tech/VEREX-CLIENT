# VEREX CLIENT — Android starter project

Starter project for the VEREX CLIENT concept, using a black + neon-blue design.

## Included
- Native Kotlin Android dashboard
- Minecraft Bedrock package detection (`com.mojang.minecraftpe`)
- Installed version name and version code display
- Launch Minecraft using Android's package launch intent
- Basic floating V icon and overlay panel (requires explicit user-granted overlay permission)
- GitHub Actions workflow to build a debug APK in the cloud

## Important limitations
- The Microsoft sign-in button is a placeholder. Real sign-in requires registering VEREX CLIENT in Microsoft Entra and configuring MSAL redirect details. Do not collect Microsoft passwords inside VEREX.
- Overlay tab buttons are UI placeholders; they do not modify Minecraft's internal render/combat systems.
- Detecting an installed version does not prove it is the latest Play Store release. The user should check Google Play for updates.
- This project has not been verified by building against an Android SDK in this environment. GitHub Actions is included to run a real cloud build and expose compiler errors.

## Build on GitHub from Android
1. Create a new repository on GitHub.
2. Upload the files and folders from this project (not only the ZIP file) to the repository root. Keep the `.github/workflows/android-build.yml` path intact.
3. Commit to the `main` branch.
4. Open the repository's **Actions** tab and open **Build VEREX CLIENT APK**.
5. Wait for the workflow to finish. If it fails, open the failed run and inspect the build log.
6. If successful, open the run's **Artifacts** section and download `VEREX-CLIENT-debug-apk`. Extract it to get `app-debug.apk`.

## Package
Application ID: `com.verex.launcher`
Minimum Android: 8.0 (API 26)
Target SDK: 35
